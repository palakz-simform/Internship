// Option Store
import { defineStore } from 'pinia'
export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 1,
    name: 'sonam',
    items: ['Java']
  }),

  // state: () => {
  //   return {
  //     count: 1,
  //     name: 'sonam',
  //     items: ['Java']
  //   }
  // },

  getters: {
    doubleCount: state => state.count * 2
  },
  actions: {
    increment() {
      this.count++
    }
  }
})