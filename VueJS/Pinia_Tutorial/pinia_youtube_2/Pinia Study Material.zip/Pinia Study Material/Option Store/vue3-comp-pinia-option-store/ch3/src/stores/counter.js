// Option Store
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 1
  }),
  getters: {
    // doubleCount: state => state.count * 2

    // Using Normal Function
    doubleCount(state) {
      return state.count * 2
    },

    // Using getter inside getter, Do not use Arrow Function
    doublePlusOne(state) {
      return this.doubleCount + 1
    },

    // Passing Arguments to getters
    // getUserId: (state) => {
    //   return (userId) => console.log(userId)
    // },
    getUserId: (state) => {
      return (userId) => {
        if (userId === 5) {
          return 'Welcome Sonam'
        }
        return 'Welcome Guest'
      }
    },

    // Using Other Store Getter
    studentStoreGetter(state) {
      const student = useStudentStore()
      console.log(student.name)
      console.log(student.fullName)
      return student.fullName + state.count
    }
  },
  actions: {
    increment() {
      this.count++
    }
  }
})