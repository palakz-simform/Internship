// Option Store
import { defineStore } from 'pinia'
export const useStudentStore = defineStore('stu', {
  state: () => ({
    name: 'Sonam',
  }),

  getters: {
    fullName: state => state.name + ' Hindustani',
  },

})