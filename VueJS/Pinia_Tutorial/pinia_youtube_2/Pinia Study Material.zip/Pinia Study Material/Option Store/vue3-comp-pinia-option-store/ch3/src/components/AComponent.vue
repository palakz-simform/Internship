<script setup>
import { useCounterStore } from "../stores/counter";
const store = useCounterStore();

// Passing Arguments to getters
const getUserId = store.getUserId;
</script>

<template>
  <h1>A Component</h1>
  <h2>Count: {{ store.count }}</h2>
  <h2>Double Count: {{ store.doubleCount }}</h2>
  <button @click="store.increment">Increment</button>

  <h2>Double Plus One: {{ store.doublePlusOne }}</h2>
  <h2>User: {{ getUserId(3) }}</h2>
  <h2>Student Store Getter: {{ store.studentStoreGetter }}</h2>
</template>

<style></style>
