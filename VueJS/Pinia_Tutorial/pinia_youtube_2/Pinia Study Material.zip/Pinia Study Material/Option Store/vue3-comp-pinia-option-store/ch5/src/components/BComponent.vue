<script setup>
import { useCounterStore } from "../stores/counter";
const store = useCounterStore();
</script>

<template>
  <hr />
  <h1>B Component</h1>
  <h2>Count: {{ store.count }}</h2>
  <h2>Double Count: {{ store.doubleCount }}</h2>

  <!-- Using Composables in Pinia Store -->
  <h2>Full Name: {{ store.name.firstName }} {{ store.name.lastName }}</h2>
</template>

<style></style>
