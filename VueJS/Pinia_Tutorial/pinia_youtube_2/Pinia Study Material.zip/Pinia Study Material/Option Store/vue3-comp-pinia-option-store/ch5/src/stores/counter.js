// Option Store
import { defineStore } from 'pinia'
import { useName } from '../composables/name'
export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 1,
    name: useName()
  }),
  getters: {
    doubleCount: state => state.count * 2
  },
  actions: {
    increment() {
      this.count++
    }
  }
})