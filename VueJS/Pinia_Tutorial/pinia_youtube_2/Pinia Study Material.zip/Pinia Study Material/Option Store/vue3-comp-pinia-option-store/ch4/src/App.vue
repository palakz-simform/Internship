<!-- Topic: Actions -->
<script setup>
import AComponent from "./components/AComponent.vue";
import BComponent from "./components/BComponent.vue";
</script>

<template>
  <AComponent />
  <BComponent />
</template>

<style></style>
