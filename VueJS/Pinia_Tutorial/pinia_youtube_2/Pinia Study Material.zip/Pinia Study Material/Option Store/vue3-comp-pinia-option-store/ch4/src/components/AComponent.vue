<script setup>
import { useCounterStore } from "../stores/counter";
import { onMounted } from "vue";
const store = useCounterStore();
onMounted(store.getSinglePost);
</script>

<template>
  <h1>A Component</h1>
  <h2>Count: {{ store.count }}</h2>
  <h2>Double Count: {{ store.doubleCount }}</h2>
  <button @click="store.increment">Increment</button>

  <!-- Using other store action -->
  <h2>Show Result: {{ store.showExamResult() }}</h2>

  <!-- Async Action -->
  <h1 v-if="store.postData">{{ store.postData }}</h1>
</template>

<style></style>
