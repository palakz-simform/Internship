// Option Store
import { defineStore } from 'pinia'
import { useStudentStore } from './student'
import axios from 'axios'
export const useCounterStore = defineStore('counter', {
  state: () => ({
    count: 1,
    postData: null
  }),
  getters: {
    doubleCount: state => state.count * 2
  },
  actions: {
    increment() {
      this.count++
    },

    // Using other store action
    showExamResult() {
      const student = useStudentStore()
      // console.log(student.getGraceMarks())
      return this.count + student.getGraceMarks()
    },

    // Async Action
    async getSinglePost() {
      try {
        const res = await axios('https://jsonplaceholder.typicode.com/posts/5')
        this.postData = res.data
      } catch (error) {
        console.log(error)
      }
    }
  }
})