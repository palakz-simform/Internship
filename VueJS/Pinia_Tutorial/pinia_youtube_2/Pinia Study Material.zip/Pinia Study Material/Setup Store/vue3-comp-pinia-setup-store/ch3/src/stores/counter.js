// Setup Store
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
import { useName } from '../composables/name'
export const useCounterStore = defineStore('counter', () => {
  const count = ref(1)    // state
  const name = useName()
  const doubleCount = computed(() => count.value * 2) // Getters
  function increment() {
    count.value++
  }
  return { count, name, doubleCount, increment }
})