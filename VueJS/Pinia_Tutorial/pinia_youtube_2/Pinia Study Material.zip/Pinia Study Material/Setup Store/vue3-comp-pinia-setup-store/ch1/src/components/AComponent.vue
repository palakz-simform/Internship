<!-- 
  State become ref 
  Getter become Computed Property
  Actions become Methods/Function
-->
<script setup>
import { useCounterStore } from "../stores/counter";
import { storeToRefs } from "pinia";
const store = useCounterStore();
// console.log(store);

// We can not destructure like this
// const { count, doubleCount, increment } = store;

// Correct way to destructure
// const { count, doubleCount } = storeToRefs(store);

// This action can be destructured normally
// const { increment } = store;
</script>
<template>
  <h1>A Component</h1>
  <h2>Count: {{ store.count }}</h2>
  <h2>Double Count: {{ store.doubleCount }}</h2>
  <button @click="store.increment">Increment</button>

  <!-- <h2>Count: {{ count }}</h2>
  <h2>Double Count: {{ doubleCount }}</h2>
  <button @click="increment">Increment</button> -->
</template>
<style></style>
