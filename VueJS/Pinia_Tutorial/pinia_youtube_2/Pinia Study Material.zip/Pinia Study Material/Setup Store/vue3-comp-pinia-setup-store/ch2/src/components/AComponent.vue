<script setup>
import { useCounterStore } from "../stores/counter";
const store = useCounterStore();
// store.count = 10;
// store.secondCount = 20;  // It wont have reactivity becoz There is no secondCount in store

// Mutating State passing Object
// store.$patch({
//   count: store.count + 10,
//   name: "Raj",
// });

// Mutating State passing Function
// store.$patch((state) => {
//   state.items.push("Vue3");
//   state.count = 30;
// });

// Replacing State
// store.$state = { count: 50 }; // It is equivalent store.$patch({ count: 50 })
console.log(store);
</script>
<template>
  <h1>A Component</h1>
  <h2>Count: {{ store.count }}</h2>
  <h2>Double Count: {{ store.doubleCount }}</h2>
  <!-- <h2>Second Count: {{ store.secondCount }}</h2> -->
  <button @click="store.increment">Increment</button>

  <h2>Name: {{ store.name }}</h2>
  <h2>Items: {{ store.items }}</h2>
</template>
<style></style>
