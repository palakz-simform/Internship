// Setup Store
import { defineStore } from 'pinia'
import { ref, computed } from 'vue'
export const useCounterStore = defineStore('counter', () => {
  const count = ref(1)        // state
  const name = ref('Sonam')   // State
  const items = ref(['Java'])   // State
  const doubleCount = computed(() => count.value * 2) // Getters
  function increment() {
    count.value++
  }
  return { count, name, items, doubleCount, increment }
})