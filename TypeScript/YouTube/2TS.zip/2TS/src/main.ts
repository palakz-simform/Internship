let userName = 'Dave'
console.log(userName)


let a = 12
let b = 'asd'
